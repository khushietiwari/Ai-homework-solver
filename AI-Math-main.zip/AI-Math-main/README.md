# AI-Math
An AI based math problems solver which can solve basic math problems and uses text recognition services to help solve homework
